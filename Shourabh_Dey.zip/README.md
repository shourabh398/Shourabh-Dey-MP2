# Shourabh Dey – Responsive Portfolio Website

A responsive personal portfolio for Shourabh Dey, a CSE student at IIUC in Bangladesh.

## Sections
Home, About Me, Skills, Featured Projects, and Contact.

## Technologies
HTML5, Tailwind CSS (CDN), and JavaScript.

## Run
Open `index.html` in a browser. Internet access is needed for the Tailwind CSS CDN.

Note: The contact form is a front-end demo and does not send or store emails.
